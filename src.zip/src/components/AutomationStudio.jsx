import { useEffect, useMemo, useState } from 'react'
import {
  Activity,
  Braces,
  CalendarClock,
  Plus,
  RefreshCw,
  ShieldCheck,
  Workflow,
  X,
  Zap,
} from 'lucide-react'
import { crmApi, getErrorMessage } from '../api/crmApi'

const runtimePrimitives = [
  ['VALIDATE', 'Stop execution when a configured condition fails.'],
  ['CREATE_RECORD', 'Create a record in any configured target module.'],
  ['UPDATE_FIELDS', 'Update current or referenced records through the operation gateway.'],
  ['PUBLISH_EVENT', 'Emit any registered event key with a validated payload.'],
  ['AGGREGATE_RECORDS', 'Count, sum, average, minimum, maximum or group records.'],
  ['CALL_ACTION', 'Compose reusable actions and workflows.'],
]

const emptyDraft = {
  kind: 'EVENT',
  title: '',
  technicalKey: '',
  category: 'CUSTOM',
  schemaId: '',
  eventKey: '',
  actionType: 'JSON_PROGRAM',
  failurePolicy: 'ALL_OR_NOTHING',
  conditionExpression: '',
  actionId: '',
  workflowId: '',
  priority: 100,
  cronExpression: 'DAILY@23:55',
  timezone: Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC',
  checkerPermission: 'MODULE_OPERATION_CHECK',
  approverPermission: 'MODULE_OPERATION_APPROVE',
  selfDecisionAllowed: false,
  program: '[\n  {\n    "operation": "VALIDATE",\n    "condition": true,\n    "message": "Validation failed"\n  }\n]',
  workflowSteps: '[\n  {\n    "type": "REQUEST_APPROVAL",\n    "policy": {\n      "steps": [\n        { "sequence": 1, "label": "Checker review", "requiredPermission": "MODULE_OPERATION_CHECK" },\n        { "sequence": 2, "label": "Final approval", "requiredPermission": "MODULE_OPERATION_APPROVE" }\n      ],\n      "selfDecisionAllowed": false\n    }\n  }\n]',
}

function safeJson(text, fallback) {
  try {
    const value = JSON.parse(text)
    return value
  } catch {
    return fallback
  }
}

function DefinitionDialog({ open, onClose, onSaved, eventTypes, actions, workflows }) {
  const [draft, setDraft] = useState(emptyDraft)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState('')

  useEffect(() => {
    if (open) {
      setDraft(emptyDraft)
      setError('')
    }
  }, [open])

  if (!open) return null

  const save = async (event) => {
    event.preventDefault()
    setSaving(true)
    setError('')
    try {
      const key = draft.technicalKey.trim().toUpperCase().replace(/[^A-Z0-9_]+/g, '_')
      if (!key) throw new Error('Technical key is required')

      if (draft.kind === 'EVENT') {
        await crmApi.createEventType({
          eventKey: key,
          eventName: draft.title || key,
          category: draft.category || 'CUSTOM',
          payloadSchema: {},
        })
      } else if (draft.kind === 'ACTION') {
        const program = safeJson(draft.program, null)
        if (!Array.isArray(program)) throw new Error('Action program must be a valid JSON array')
        await crmApi.validateActionProgram(program)
        await crmApi.saveAction({
          actionKey: key,
          title: draft.title || key,
          schemaId: draft.schemaId || null,
          actionType: draft.actionType,
          inputDefinition: [],
          outputDefinition: [],
          config: { program },
          virtualAction: true,
          active: true,
          version: 1,
        })
      } else if (draft.kind === 'WORKFLOW') {
        const steps = safeJson(draft.workflowSteps, null)
        if (!Array.isArray(steps)) throw new Error('Workflow steps must be a valid JSON array')
        await crmApi.saveWorkflow({
          workflowKey: key,
          title: draft.title || key,
          schemaId: draft.schemaId || null,
          steps,
          compensationSteps: [],
          failurePolicy: draft.failurePolicy,
          active: true,
          version: 1,
        })
      } else if (draft.kind === 'TRIGGER') {
        if (!draft.schemaId) throw new Error('Module/schema ID is required for a trigger')
        if (!draft.eventKey) throw new Error('Event is required')
        if (!draft.actionId && !draft.workflowId) throw new Error('Choose an action or workflow')
        await crmApi.saveTrigger({
          schemaId: draft.schemaId,
          eventType: draft.eventKey,
          conditionExpression: draft.conditionExpression || null,
          actionId: draft.actionId || null,
          workflowId: draft.workflowId || null,
          priority: Number(draft.priority || 100),
          active: true,
        })
      } else if (draft.kind === 'SCHEDULE') {
        if (!draft.eventKey) throw new Error('Event is required')
        await crmApi.saveEventSchedule({
          title: draft.title || key,
          eventKey: draft.eventKey,
          cronExpression: draft.cronExpression,
          timezone: draft.timezone,
          active: true,
          payload: {},
        })
      }

      await onSaved()
      onClose()
    } catch (e) {
      setError(getErrorMessage(e) || e.message)
    } finally {
      setSaving(false)
    }
  }

  return (
      <div className="studio-dialog-backdrop" role="presentation">
        <form className="studio-dialog" onSubmit={save}>
          <header>
            <div>
              <span className="eyebrow">Automation definition</span>
              <h2>Create reusable definition</h2>
              <p>Nothing here is module-name hardcoded. Definitions reference registered events, module IDs and permission keys.</p>
            </div>
            <button type="button" className="icon-button" onClick={onClose}><X size={19} /></button>
          </header>

          {error && <div className="notice-banner error">{error}</div>}

          <div className="definition-kind-grid">
            {['EVENT', 'ACTION', 'WORKFLOW', 'TRIGGER', 'SCHEDULE'].map((kind) => (
                <button key={kind} type="button" className={draft.kind === kind ? 'selected' : ''} onClick={() => setDraft({ ...draft, kind })}>{kind}</button>
            ))}
          </div>

          <div className="form-grid-two">
            <label><span>Name</span><input required value={draft.title} onChange={(e) => setDraft({ ...draft, title: e.target.value })} placeholder="Readable business name" /></label>
            <label><span>Technical key</span><input required value={draft.technicalKey} onChange={(e) => setDraft({ ...draft, technicalKey: e.target.value })} placeholder="e.g. ORDER_SUBMITTED" /></label>
          </div>

          {draft.kind === 'EVENT' && (
              <label><span>Category</span><input value={draft.category} onChange={(e) => setDraft({ ...draft, category: e.target.value })} placeholder="CUSTOM" /></label>
          )}

          {draft.kind === 'ACTION' && (
              <>
                <div className="form-grid-two">
                  <label><span>Module/schema ID (optional)</span><input value={draft.schemaId} onChange={(e) => setDraft({ ...draft, schemaId: e.target.value })} /></label>
                  <label><span>Action type</span><select value={draft.actionType} onChange={(e) => setDraft({ ...draft, actionType: e.target.value })}><option value="JSON_PROGRAM">JSON program</option><option value="VALIDATE">Validate</option><option value="WORKFLOW">Workflow</option></select></label>
                </div>
                <label><span>Validated program</span><textarea rows="12" value={draft.program} onChange={(e) => setDraft({ ...draft, program: e.target.value })} /></label>
              </>
          )}

          {draft.kind === 'WORKFLOW' && (
              <>
                <div className="form-grid-two">
                  <label><span>Module/schema ID (optional)</span><input value={draft.schemaId} onChange={(e) => setDraft({ ...draft, schemaId: e.target.value })} /></label>
                  <label><span>Failure policy</span><select value={draft.failurePolicy} onChange={(e) => setDraft({ ...draft, failurePolicy: e.target.value })}><option>ALL_OR_NOTHING</option><option>BEST_EFFORT</option><option>COMPENSATE</option></select></label>
                </div>
                <div className="approval-flow-preview">
                  <ShieldCheck size={20} />
                  <div><strong>Checker → Approver</strong><span>Use permission keys, not role names. The workflow JSON below stores the reusable approval step definition.</span></div>
                </div>
                <label><span>Workflow steps</span><textarea rows="16" value={draft.workflowSteps} onChange={(e) => setDraft({ ...draft, workflowSteps: e.target.value })} /></label>
              </>
          )}

          {draft.kind === 'TRIGGER' && (
              <>
                <div className="form-grid-two">
                  <label><span>Module/schema ID</span><input required value={draft.schemaId} onChange={(e) => setDraft({ ...draft, schemaId: e.target.value })} /></label>
                  <label><span>Registered event</span><select required value={draft.eventKey} onChange={(e) => setDraft({ ...draft, eventKey: e.target.value })}><option value="">Select event</option>{eventTypes.map((item) => <option key={item.eventKey} value={item.eventKey}>{item.eventName || item.eventKey}</option>)}</select></label>
                  <label><span>Workflow</span><select value={draft.workflowId} onChange={(e) => setDraft({ ...draft, workflowId: e.target.value, actionId: '' })}><option value="">None</option>{workflows.map((item) => <option key={item.id} value={item.id}>{item.title || item.workflowKey}</option>)}</select></label>
                  <label><span>Action</span><select value={draft.actionId} onChange={(e) => setDraft({ ...draft, actionId: e.target.value, workflowId: '' })}><option value="">None</option>{actions.map((item) => <option key={item.id} value={item.id}>{item.title || item.actionKey}</option>)}</select></label>
                  <label><span>Condition expression</span><input value={draft.conditionExpression} onChange={(e) => setDraft({ ...draft, conditionExpression: e.target.value })} placeholder="Optional" /></label>
                  <label><span>Priority</span><input type="number" value={draft.priority} onChange={(e) => setDraft({ ...draft, priority: e.target.value })} /></label>
                </div>
              </>
          )}

          {draft.kind === 'SCHEDULE' && (
              <div className="form-grid-two">
                <label><span>Registered event</span><select required value={draft.eventKey} onChange={(e) => setDraft({ ...draft, eventKey: e.target.value })}><option value="">Select event</option>{eventTypes.map((item) => <option key={item.eventKey} value={item.eventKey}>{item.eventName || item.eventKey}</option>)}</select></label>
                <label><span>Schedule expression</span><input value={draft.cronExpression} onChange={(e) => setDraft({ ...draft, cronExpression: e.target.value })} /></label>
                <label><span>Timezone</span><input value={draft.timezone} onChange={(e) => setDraft({ ...draft, timezone: e.target.value })} /></label>
              </div>
          )}

          <footer>
            <button type="button" className="button button-secondary" onClick={onClose}>Cancel</button>
            <button className="button button-primary" disabled={saving}>{saving ? 'Saving…' : 'Save definition'}</button>
          </footer>
        </form>
      </div>
  )
}

export default function AutomationStudio({ onOpenIntegrations }) {
  const [eventTypes, setEventTypes] = useState([])
  const [schedules, setSchedules] = useState([])
  const [recentEvents, setRecentEvents] = useState([])
  const [actions, setActions] = useState([])
  const [workflows, setWorkflows] = useState([])
  const [triggers, setTriggers] = useState([])
  const [executions, setExecutions] = useState([])
  const [activeTab, setActiveTab] = useState('events')
  const [dialogOpen, setDialogOpen] = useState(false)
  const [error, setError] = useState('')

  const refresh = async () => {
    setError('')
    try {
      const [types, scheduleRows, events, actionRows, workflowRows, triggerRows, executionRows] = await Promise.all([
        crmApi.listEventTypes(),
        crmApi.listEventSchedules().catch(() => []),
        crmApi.listRecentEvents?.(20).catch(() => []) || Promise.resolve([]),
        crmApi.listActions().catch(() => []),
        crmApi.listWorkflows().catch(() => []),
        crmApi.listTriggers().catch(() => []),
        crmApi.listAutomationExecutions().catch(() => []),
      ])
      setEventTypes(Array.isArray(types) ? types : [])
      setSchedules(Array.isArray(scheduleRows) ? scheduleRows : [])
      setRecentEvents(Array.isArray(events) ? events : [])
      setActions(Array.isArray(actionRows) ? actionRows : [])
      setWorkflows(Array.isArray(workflowRows) ? workflowRows : [])
      setTriggers(Array.isArray(triggerRows) ? triggerRows : [])
      setExecutions(Array.isArray(executionRows) ? executionRows : [])
    } catch (e) {
      setError(getErrorMessage(e))
    }
  }

  useEffect(() => { refresh() }, [])
  const customEvents = useMemo(() => eventTypes.filter((item) => !item.systemEvent), [eventTypes])
  const tabs = [
    ['events', 'Events', eventTypes.length],
    ['schedules', 'Schedules', schedules.length],
    ['definitions', 'Definitions', actions.length + workflows.length + triggers.length],
    ['runtime', 'Runtime', runtimePrimitives.length],
    ['executions', 'Executions', recentEvents.length],
  ]

  return (
      <section className="workspace-page automation-page">
        <header className="automation-hero">
          <div><span className="eyebrow">Configurable event runtime</span><h1>Automation Studio</h1><p>Build business behaviour from registered events, triggers, workflows, schedules and safe action primitives.</p></div>
          <div className="hero-actions"><button className="button button-secondary" type="button" onClick={refresh}><RefreshCw size={17}/> Refresh</button><button className="button button-primary" type="button" onClick={() => setDialogOpen(true)}><Plus size={18}/> New definition</button></div>
        </header>
        {error && <div className="notice-banner error">{error}</div>}

        <div className="automation-metrics">
          <article><div className="metric-icon"><Workflow size={19}/></div><strong>{eventTypes.length}</strong><span>Registered events</span></article>
          <article><div className="metric-icon"><CalendarClock size={19}/></div><strong>{schedules.filter((item) => item.active !== false).length}</strong><span>Active schedules</span></article>
          <article><div className="metric-icon"><Activity size={19}/></div><strong>{executions.length}</strong><span>Recent executions</span></article>
          <article><div className="metric-icon"><Braces size={19}/></div><strong>{runtimePrimitives.length}</strong><span>Action primitives</span></article>
        </div>

        <div className="studio-tabs">{tabs.map(([key, label, count]) => <button key={key} className={activeTab === key ? 'active' : ''} onClick={() => setActiveTab(key)}><span>{label}</span><b>{count}</b></button>)}</div>

        {activeTab === 'events' && <section className="surface-card studio-panel"><div className="section-title-row"><div><span className="eyebrow">Event registry</span><h2>Business and lifecycle events</h2></div><span className="status-chip ready">{customEvents.length} custom</span></div><div className="event-table"><div className="event-table-head"><span>Name</span><span>Key</span><span>Category</span><span>Type</span></div>{eventTypes.map((event) => <article key={event.id || event.eventKey}><strong>{event.eventName || event.eventKey}</strong><code>{event.eventKey}</code><span>{event.category || 'General'}</span><b className={event.systemEvent ? '' : 'custom'}>{event.systemEvent ? 'System' : 'Custom'}</b></article>)}</div></section>}

        {activeTab === 'schedules' && <section className="surface-card studio-panel"><div className="section-title-row"><div><span className="eyebrow">Schedules</span><h2>Configured business clocks</h2></div></div><div className="schedule-list">{schedules.map((row) => <article key={row.id}><div className="schedule-icon"><CalendarClock size={18}/></div><div><strong>{row.title}</strong><small>{row.eventKey}</small><span>{row.cronExpression} · {row.timezone || 'UTC'}</span></div><b className={row.active ? 'active' : ''}>{row.active ? 'Active' : 'Paused'}</b></article>)}{!schedules.length && <div className="mini-empty">No schedules configured.</div>}</div></section>}

        {activeTab === 'definitions' && <div className="studio-layout polished-layout"><section className="surface-card studio-panel"><div className="section-title-row"><div><span className="eyebrow">Actions and workflows</span><h2>Reusable definitions</h2></div></div><div className="event-table"><div className="event-table-head"><span>Name</span><span>Key</span><span>Scope</span><span>Type</span></div>{actions.map((item) => <article key={item.id}><strong>{item.title}</strong><code>{item.actionKey}</code><span>{item.schemaId || 'App'}</span><b>Action</b></article>)}{workflows.map((item) => <article key={item.id}><strong>{item.title}</strong><code>{item.workflowKey}</code><span>{item.schemaId || 'App'}</span><b>Workflow</b></article>)}</div></section><section className="surface-card studio-panel"><div className="section-title-row"><div><span className="eyebrow">Listeners</span><h2>Triggers</h2></div></div><div className="schedule-list">{triggers.map((item) => <article key={item.id}><div className="schedule-icon"><Zap size={18}/></div><div><strong>{item.eventType}</strong><small>{item.schemaId}</small><span>{item.conditionExpression || 'Always'}</span></div><b className={item.active !== false ? 'active' : ''}>{item.active !== false ? 'Active' : 'Paused'}</b></article>)}</div></section></div>}

        {activeTab === 'runtime' && <div className="runtime-grid">{runtimePrimitives.map(([name, description]) => <article className="runtime-card" key={name}><div className="runtime-icon"><Zap size={18}/></div><span>Engine primitive</span><h3>{name}</h3><p>{description}</p><code>{name}</code></article>)}</div>}

        {activeTab === 'executions' && <section className="surface-card studio-panel"><div className="section-title-row"><div><span className="eyebrow">Execution journal</span><h2>Recent events and automation</h2></div></div><div className="event-table"><div className="event-table-head"><span>Event</span><span>Module</span><span>Record</span><span>Time</span></div>{recentEvents.map((item, index) => <article key={item.id || index}><strong>{item.eventKey}</strong><code>{item.module || 'App'}</code><span>{item.recordId || '—'}</span><b>{item.occurredAt || item.createdAt || '—'}</b></article>)}</div></section>}

        <div className="studio-generic-note"><ShieldCheck size={22}/><div><h3>Checker and approver remain permission-driven</h3><p>Use <code>MODULE_OPERATION_CHECK</code> and <code>MODULE_OPERATION_APPROVE</code> inside workflow approval steps. Role display names can be anything.</p><button type="button" className="button button-secondary" onClick={onOpenIntegrations}>Configure integrations</button></div></div>

        <DefinitionDialog open={dialogOpen} onClose={() => setDialogOpen(false)} onSaved={refresh} eventTypes={eventTypes} actions={actions} workflows={workflows} />
      </section>
  )
}
